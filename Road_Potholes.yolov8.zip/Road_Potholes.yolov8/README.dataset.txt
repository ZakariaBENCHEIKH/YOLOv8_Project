# Road with Potholes. > 2023-04-11 11:40pm
https://universe.roboflow.com/road-with-potholes/road-with-potholes.

Provided by a Roboflow user
License: CC BY 4.0

